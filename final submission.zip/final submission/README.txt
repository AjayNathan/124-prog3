CS 124 Programming Assignment
Avinash Saraf and Ajay Nathan

Running kk.c:
1. Type "make" into terminal
2. Type "python generate_inputfile.py"
3. Type "./kk input.txt"

Running the randomized algorithms:
1. Type "python randomized_algorithms.py"
